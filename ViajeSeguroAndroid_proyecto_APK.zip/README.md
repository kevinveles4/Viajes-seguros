# Viaje Seguro para Android

Este proyecto empaqueta el prototipo HTML de Viaje Seguro dentro de una aplicación Android sencilla (WebView).

## Crear el APK con GitHub

1. Crea un repositorio en GitHub.
2. Sube **todo el contenido** de esta carpeta (no la carpeta ZIP como un único archivo).
3. Abre la pestaña **Actions** del repositorio.
4. Selecciona **Build Viaje Seguro APK** y pulsa **Run workflow**. También se inicia al subir cambios a `main`.
5. Cuando termine, abre la ejecución completada y descarga el artefacto **Viaje-Seguro-APK**.
6. Dentro del ZIP descargado estará `app-debug.apk`. Ábrelo en tu Samsung y permite instalar desde esa fuente si Android lo solicita.

## Importante

Es una primera versión de prueba. El mapa y las zonas de colores son ilustrativos; no representan riesgos reales. El clima, teléfonos oficiales y otros servicios todavía no están conectados a fuentes en tiempo real.
